<?php $__env->startSection('content_loged'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(utf8_encode(session()->get('success'))); ?>  
    </div><br />
  <?php endif; ?>
<a href="<?php echo e(utf8_encode(route('shares.create'))); ?>" class="btn btn-primary" style="background-color: green;">+ Add</a>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>имя</td>
          <td>Stock Price</td>
          <td>Stock Quantity</td>
          <td>Fname</td>
          <td colspan="2">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $shares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $share): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(utf8_encode($share->id)); ?></td>
            <td><?=$share->share_name;?></td>
            <td><?php echo e(utf8_encode($share->share_price)); ?></td>
            <td><?php echo e(utf8_encode($share->share_qty)); ?></td>
            <td>  <img src="<?php echo e(utf8_encode(asset('images/'.$share->share_photo.''))); ?>" alt="" width="100px;" /> </td>
            <td><a href="<?php echo e(utf8_encode(route('shares.edit',$share->id))); ?>" class="btn btn-primary">Edit</a></td>
            <td>
                <form action="<?php echo e(utf8_encode(route('shares.destroy', $share->id))); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_not_loged'); ?>
	<section class="no-touch">

  <div class="wrap">
<?php $__currentLoopData = $shares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $share): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="box">
      <div class="boxInner">
        <img src="<?php echo e(utf8_encode(asset('images/'.$share->share_photo.''))); ?>" />
        <div class="titleBox"><p><?=$share->share_name; ?></p><br /> <p>цена: <?php echo e(utf8_encode($share->share_price)); ?></p> </div>
      </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\lara_vel\resources\views/shares/index.blade.php ENDPATH**/ ?>