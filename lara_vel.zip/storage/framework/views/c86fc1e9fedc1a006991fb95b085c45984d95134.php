<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Example</title>
  <link href="<?php echo e(utf8_encode(asset('css/app.css'))); ?>" rel="stylesheet" type="text/css" />
   <script src="<?php echo e(utf8_encode(asset('js/app.js'))); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(utf8_encode(asset('css/app.css'))); ?>" rel="stylesheet">
    <link href="<?php echo e(utf8_encode(asset('css/gallery.css'))); ?>" rel="stylesheet">
</head>
<body>


<nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(utf8_encode(url('/'))); ?>">
                    <?php echo e(utf8_encode(config('app.name', 'Laravel'))); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(utf8_encode(__('Toggle navigation'))); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(utf8_encode(route('login'))); ?>"><?php echo e(utf8_encode(__('Login'))); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(utf8_encode(route('register'))); ?>"><?php echo e(utf8_encode(__('Register'))); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(utf8_encode(Auth::user()->name)); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(utf8_encode(route('logout'))); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(utf8_encode(__('Logout'))); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(utf8_encode(route('logout'))); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>


  <div class="container">
  <?php if(auth()->guard()->guest()): ?>
    <?php echo $__env->yieldContent('content_not_loged'); ?>
  <?php else: ?>
  	<?php echo $__env->yieldContent('content_loged'); ?>
  <?php endif; ?>
  </div>
  <script src="<?php echo e(utf8_encode(asset('js/app.js'))); ?>" type="text/js"></script>
</body>
</html><?php /**PATH C:\wamp\www\lara_vel\resources\views/layout.blade.php ENDPATH**/ ?>